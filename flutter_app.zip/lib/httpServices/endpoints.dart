class EndPoints {
  static const BASEURL = "https://www.elmanhg.com/wp-json/wp/v2";
  static const CATEGORIES = BASEURL + "/categories";
  static const HOMEADS = BASEURL + "/posts?per_page=20";
  static const SECTIONLISTDATA = BASEURL + "/posts";
  static const DETAILSDATA = BASEURL + "/posts";
  static const SEARCH = BASEURL + "/search";
}
